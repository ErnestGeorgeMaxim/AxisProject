﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AxisProject.Models
{
    public class CalculatorModel
    {
        public string CurrentInput { get; private set; } = "0";
        public string Expression { get; private set; } = "";
        private double _memory = 0;
        private double _currentValue = 0;
        private string _currentOperator = "";
        private bool _isNewOperation = true;
        private bool _hasCalculated = false;

        public void AppendNumber(string number)
        {
            if (_hasCalculated)
            {
                Clear();
                _hasCalculated = false;
            }

            if (number == ".")
            {
                if (CurrentInput.Contains("."))
                    return;

                CurrentInput += ".";
                _isNewOperation = false;
                return;
            }

            if (CurrentInput == "0")
                CurrentInput = number;
            else
                CurrentInput += number;

            if (_isNewOperation)
            {
                _isNewOperation = false;
            }
        }


        public void SetOperator(string op)
        {
            if (_hasCalculated)
            {
                Expression = "";
                _hasCalculated = false;
            }

            if (string.IsNullOrEmpty(Expression))
            {
                Expression = CurrentInput + op;
            }
            else if (_isNewOperation)
            {
                Expression = Expression.Substring(0, Expression.Length - 2) + op;
            }
            else
            {
                Expression += CurrentInput + op;
            }

            _currentOperator = op;
            _currentValue = double.Parse(CurrentInput);
            CurrentInput = "0";
            _isNewOperation = true;
        }

        public string Calculate()
        {
            double secondOperand = double.Parse(CurrentInput);
            double result = _currentValue;

            if (!_hasCalculated)
            {
                Expression += CurrentInput;
            }

            if (CurrentInput.EndsWith("%"))
            {
                secondOperand = _currentValue * (double.Parse(CurrentInput.TrimEnd('%')) / 100);
            }
            else
            {
                switch (_currentOperator)
                {
                    case "+": result += secondOperand; break;
                    case "−": result -= secondOperand; break;
                    case "×": result *= secondOperand; break;
                    case "÷":
                        if (secondOperand == 0)
                            return "Error";
                        result /= secondOperand;
                        break;
                }
            }

            Expression = "";
            _hasCalculated = true;
            CurrentInput = result.ToString("F6").TrimEnd('0').TrimEnd('.');
            return CurrentInput;
        }

        public string ApplyPercentage()
        {
            double value = double.Parse(CurrentInput);

            if (string.IsNullOrEmpty(_currentOperator))
            {
                return CurrentInput;
            }

            switch (_currentOperator)
            {
                case "+":
                case "−":
                    value = _currentValue * (value / 100);
                    break;
                case "×":
                    value = value / 100;
                    break;
                case "÷":
                    value = value / 100;
                    break;
            }

            CurrentInput = value.ToString("F6").TrimEnd('0').TrimEnd('.');
            return GetDisplayText();
        }

        public void Clear()
        {
            CurrentInput = "0";
            Expression = "";
            _currentValue = 0;
            _currentOperator = "";
            _isNewOperation = true;
            _hasCalculated = false;
        }

        public void ClearEntry()
        {
            CurrentInput = "0";
        }

        
        public void Backspace()
        {
            if (CurrentInput.Length > 1)
                CurrentInput = CurrentInput[..^1];
            else
                CurrentInput = "0";
        }

        public string Square()
        {
            string originalInput = CurrentInput;
            double result = double.Parse(CurrentInput) * double.Parse(CurrentInput);
            if (!string.IsNullOrEmpty(_currentOperator) && !_isNewOperation)
            {
                CurrentInput = result.ToString("F6").TrimEnd('0').TrimEnd('.');

                return GetDisplayText();
            }
            else
            {
                Expression = $"{originalInput}² = ";
                _hasCalculated = true;
                CurrentInput = result.ToString("F6").TrimEnd('0').TrimEnd('.');
                return CurrentInput;
            }
        }

        public string SquareRoot()
        {
            string originalInput = CurrentInput;

            double result = Math.Sqrt(double.Parse(CurrentInput));
            
            if (!string.IsNullOrEmpty(_currentOperator) && !_isNewOperation)
            {
                CurrentInput = result.ToString("F6").TrimEnd('0').TrimEnd('.');

                return GetDisplayText();
            }
            else
            {
                Expression = $"√{originalInput} = ";
                _hasCalculated = true;
                CurrentInput = result.ToString("F6").TrimEnd('0').TrimEnd('.');
                return CurrentInput;
            }
        }

        public string Reciprocal()
        {
            string originalInput = CurrentInput;

            if (double.Parse(CurrentInput) == 0)
                return "Error";

            double result = 1 / double.Parse(CurrentInput);

            if (!string.IsNullOrEmpty(_currentOperator) && !_isNewOperation)
            {
                CurrentInput = result.ToString("F6").TrimEnd('0').TrimEnd('.');

                return GetDisplayText();
            }
            else
            {
                Expression = $"1/{originalInput} = ";
                _hasCalculated = true;
                CurrentInput = result.ToString("F6").TrimEnd('0').TrimEnd('.');
                return CurrentInput;
            }
        }

        public string ToggleSign()
        {
            double result = -double.Parse(CurrentInput);
            CurrentInput = result.ToString("F6").TrimEnd('0').TrimEnd('.');
            return CurrentInput;
        }


        public string GetDisplayText()
        {
            if (_hasCalculated)
            {
                return CurrentInput;
            }
            else if (string.IsNullOrEmpty(Expression))
            {
                return CurrentInput;
            }
            else
            {
                if (!_isNewOperation && CurrentInput != "0")
                {
                    double firstOperand = _currentValue;
                    double secondOperand = double.Parse(CurrentInput);
                    double runningResult = 0;

                    switch (_currentOperator)
                    {
                        case "+": runningResult = firstOperand + secondOperand; break;
                        case "−": runningResult = firstOperand - secondOperand; break;
                        case "×": runningResult = firstOperand * secondOperand; break;
                        case "÷":
                            if (secondOperand == 0)
                                runningResult = 0;
                            else
                                runningResult = firstOperand / secondOperand;
                            break;
                    }

                    return Expression + CurrentInput + "\n" + runningResult.ToString("F6").TrimEnd('0').TrimEnd('.');
                }
                else
                {
                    return Expression + (_isNewOperation ? "" : CurrentInput);
                }
            }
        }
    }
}