﻿using AxisProject.Commands;
using AxisProject.Models;
using AxisProject.Views;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace AxisProject
{
    public partial class MainWindow : Window
    {
        private Window _sidebarWindow = null!;
        private bool _isSidebarOpen = false;
        private CalculatorModel _calculator;
        private InputHandler _inputHandler;

        public MainWindow()
        {
            InitializeComponent();

            this.Focusable = true;
            this.Focus();

            _calculator = new CalculatorModel();
            _inputHandler = new InputHandler(DisplayTextBox, _calculator);

            DisplayTextBox.Text = _calculator.GetDisplayText();

            InitializeSidebar();

            if (MenuButton != null)
            {
                MenuButton.Click += MenuButton_Click;
            }
            else
            {
                foreach (var child in ButtonGrid.Children)
                {
                    if (child is Button button && button.Content?.ToString() == "☰")
                    {
                        button.Click += MenuButton_Click;
                        break;
                    }
                }
            }

            AttachButtonHandlers();

            this.LocationChanged += MainWindow_LocationChanged;
            this.KeyDown += MainWindow_KeyDown;
        }

        private void MainWindow_KeyDown(object sender, KeyEventArgs e)
        {
            _inputHandler.KeyPressHandler(sender, e);
        }

        private void MainWindow_LocationChanged(object? sender, EventArgs e)
        {
            if (_isSidebarOpen)
            {
                PositionSidebar();
            }
        }

        private void AttachButtonHandlers()
        {
            foreach (var child in ButtonGrid.Children)
            {
                if (child is Grid grid)
                {
                    foreach (var gridChild in grid.Children)
                    {
                        if (gridChild is Button button && button != MenuButton)
                        {
                            button.Click += (s, e) => _inputHandler.ButtonClickHandler(s, e);
                        }
                    }
                }
                else if (child is Button button && button != MenuButton)
                {
                    button.Click += (s, e) => _inputHandler.ButtonClickHandler(s, e);
                }
            }
        }

        private void InitializeSidebar()
        {
            _sidebarWindow = new Sidebar();
            _sidebarWindow.Width = 300;
            _sidebarWindow.Height = this.Height;
            _sidebarWindow.WindowStyle = WindowStyle.None;
            _sidebarWindow.ResizeMode = ResizeMode.NoResize;
            _sidebarWindow.ShowInTaskbar = false;

            if (_sidebarWindow is Sidebar sidebarView)
            {
                sidebarView.SetMainWindow(this);
            }
            this.Closed += (s, e) =>
            {
                _sidebarWindow.Close();
            };

            this.ContentRendered += (s, e) =>
            {
                _sidebarWindow.Owner = this;
            };
        }

        private void PositionSidebar()
        {
            _sidebarWindow.Left = this.Left + this.Width;
            _sidebarWindow.Top = this.Top;
        }
        private void MenuButton_Click(object sender, RoutedEventArgs e)
        {
            if (_isSidebarOpen)
            {
                _sidebarWindow.Hide();
            }
            else
            {
                PositionSidebar();

                _sidebarWindow.Show();
            }

            _isSidebarOpen = !_isSidebarOpen;
        }

        public void SetSidebarState(bool isOpen)
        {
            _isSidebarOpen = isOpen;
        }
    }
}