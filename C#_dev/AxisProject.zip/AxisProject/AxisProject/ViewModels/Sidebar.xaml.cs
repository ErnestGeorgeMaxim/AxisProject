﻿using System.Windows;
using System.Windows.Input;

namespace AxisProject.Views
{
    public partial class Sidebar : Window
    {
        // Reference to the main window for state synchronization
        private MainWindow _mainWindow = null!; // Using null! to indicate it will be set before use

        public Sidebar()
        {
            InitializeComponent();
        }

        public void SetMainWindow(MainWindow mainWindow)
        {
            _mainWindow = mainWindow;
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            // Update state in main window
            _mainWindow.SetSidebarState(false);
        }
    }
}